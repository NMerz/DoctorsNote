function loginUser() {

  console.log("Redirecting...")
  window.location.replace("homepage/index.php");
}
